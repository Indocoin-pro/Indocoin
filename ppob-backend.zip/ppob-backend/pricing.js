/**
 * pricing.js
 * Rumus markup tier + fungsi tanda tangan harga (Price Signer).
 *
 * Formula dasar (sudah disepakati sebelumnya):
 *   Fee    = clamp(persen% x harga_modal, floor, cap), dibulatkan ke atas Rp500
 *   Profit = Fee
 *   Harga Jual = harga_modal + Fee
 *
 * Tier markup per kategori — sesuaikan/lengkapi sesuai hasil review
 * katalog lebih lanjut.
 */

const { ethers } = require('ethers');
require('dotenv').config();

const TIERS = {
  kompetitif_ketat:  { percent: 0.10, floor: 1000, cap: 3000 },  // pulsa, data, token listrik
  kompetitif_sedang: { percent: 0.10, floor: 1500, cap: 3500 },  // BPJS, PDAM, voucher populer
  langka:            { percent: 0.10, floor: 5000, cap: 30000 }, // paket umroh, produk niche
};

function roundUpTo500(value) {
  return Math.ceil(value / 500) * 500;
}

/**
 * @param {number} hargaModal Harga modal dari katalog (Rupiah)
 * @param {string} tier       Salah satu key di TIERS
 * @returns {{ hargaJual: number, fee: number }}
 */
function hitungHargaJual(hargaModal, tier = 'kompetitif_ketat') {
  const rule = TIERS[tier] || TIERS.kompetitif_ketat;
  const feeRaw = hargaModal * rule.percent;
  const feeClamped = Math.min(Math.max(feeRaw, rule.floor), rule.cap);
  const fee = roundUpTo500(feeClamped);
  return { hargaJual: hargaModal + fee, fee };
}

const priceSignerWallet = new ethers.Wallet(process.env.PRICE_SIGNER_PRIVATE_KEY);

/**
 * Tanda tangani quote harga — HARUS identik dengan skema verifikasi
 * di kontrak (_verifyPriceSignature):
 *
 *   messageHash = keccak256(orderId, productCode, modalUsdt, profitUsdt, expiry, contractAddress)
 *   signature   = personal_sign(messageHash)
 *
 * @param {string} orderId       bytes32 hex string
 * @param {string} productCode  bytes32 hex string (hasil encodeProductCode)
 * @param {bigint} modalUsdt    dalam satuan terkecil USDT (18 desimal)
 * @param {bigint} profitUsdt   dalam satuan terkecil USDT (18 desimal)
 * @param {number} expiry        unix timestamp (detik)
 * @param {string} contractAddress alamat PPOBGateway
 */
async function signQuote(orderId, productCode, modalUsdt, profitUsdt, expiry, contractAddress) {
  const messageHash = ethers.solidityPackedKeccak256(
    ['bytes32', 'bytes32', 'uint256', 'uint256', 'uint256', 'address'],
    [orderId, productCode, modalUsdt, profitUsdt, expiry, contractAddress]
  );

  // ethers otomatis membungkus dengan prefix "\x19Ethereum Signed Message:\n32"
  // saat menandatangani 32 byte — cocok dengan skema ecrecover di kontrak.
  const signature = await priceSignerWallet.signMessage(ethers.getBytes(messageHash));
  return signature;
}

module.exports = {
  TIERS,
  hitungHargaJual,
  signQuote,
  priceSignerAddress: priceSignerWallet.address,
};
