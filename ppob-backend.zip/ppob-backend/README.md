# INDOCOIN PPOB Backend

Backend yang menjembatani smart contract `PPOBGateway` dengan API Digiflazz.

## Struktur File

| File | Fungsi |
|---|---|
| `ppob-listener.js` | **Proses utama** — dengarkan event on-chain, eksekusi ke Digiflazz, lapor hasil |
| `server.js` | API untuk frontend — hitung & tanda tangani quote harga, terima webhook Digiflazz |
| `blockchain.js` | Interaksi ke smart contract (ethers.js) |
| `digiflazz.js` | Klien API Digiflazz (topup, cek status, verifikasi webhook) |
| `pricing.js` | Rumus markup tier + tanda tangan harga (Price Signer) |
| `settle.js` | Logika bersama: terjemahkan hasil Digiflazz → aksi ke kontrak |
| `db.js` | Database lokal (SQLite) — nomor tujuan, status order, katalog produk |
| `sync-catalog.js` | Script terpisah — sync katalog harga dari Digiflazz ke database lokal |

## Setup

```bash
npm install
cp .env.example .env
# isi .env dengan kredensial asli (private key, API key Digiflazz, dst)
```

## Menjalankan

Dua proses terpisah, disarankan pakai PM2:

```bash
pm2 start ppob-listener.js --name ppob-listener
pm2 start server.js --name ppob-api
```

Sync katalog produk (jalankan sekali di awal, lalu jadwalkan berkala via cron):

```bash
node sync-catalog.js
```

## Alur Kerja

1. Frontend minta quote harga → `POST /api/quote` → dapat harga + signature
2. Frontend daftarkan nomor tujuan → `POST /api/orders/register`
3. User submit transaksi on-chain (bayar ke `PPOBGateway`)
4. `ppob-listener.js` mendeteksi event `OrderCreated` → eksekusi ke Digiflazz
5. Hasil sukses/gagal dilaporkan balik ke kontrak (`reportOrderSuccess`/`reportOrderFailed`)
6. Kalau status "Pending", webhook Digiflazz (`POST /webhook/digiflazz`) akan menyelesaikan belakangan
7. Kalau tidak ada respons sama sekali dalam 24 jam, auto-refund on-chain jalan sendiri (jaring pengaman terakhir)

## Catatan Keamanan

- `BACKEND_OPERATOR_PRIVATE_KEY` — isi BNB secukupnya untuk gas saja, wallet ini cuma bisa lapor status, tidak bisa memindahkan dana
- `PRICE_SIGNER_PRIVATE_KEY` — tidak pernah mengirim transaksi on-chain, cuma menandatangani data
- File `.env` **tidak boleh** ter-commit ke Git — sudah masuk `.gitignore`
