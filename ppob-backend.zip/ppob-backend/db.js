/**
 * db.js
 * Database lokal (SQLite) — menyimpan data yang SENGAJA tidak ditaruh
 * on-chain demi privasi: nomor HP/nomor meteran tujuan, status proses
 * Digiflazz, dan riwayat percobaan.
 *
 * Kontrak PPOBGateway hanya tahu: orderId, kode produk, jumlah bayar.
 * Database ini yang menjembatani "orderId ini nomor tujuannya apa".
 */

const Database = require('better-sqlite3');
require('dotenv').config();

const db = new Database(process.env.DB_PATH || './ppob.db');
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS order_meta (
    order_id       TEXT PRIMARY KEY,
    customer_no    TEXT NOT NULL,
    product_code   TEXT NOT NULL,
    ref_id         TEXT,
    digiflazz_status TEXT DEFAULT 'PENDING',
    onchain_status TEXT DEFAULT 'CREATED',
    retry_count    INTEGER DEFAULT 0,
    created_at     INTEGER NOT NULL,
    updated_at     INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_digiflazz_status ON order_meta(digiflazz_status);
  CREATE INDEX IF NOT EXISTS idx_onchain_status ON order_meta(onchain_status);

  -- Katalog produk hasil sync dari Digiflazz (price-list API).
  -- Diisi terpisah oleh script sync (lihat sync-catalog.js), BUKAN
  -- di-fetch langsung tiap ada quote request — sesuai anjuran resmi
  -- Digiflazz untuk tidak memanggil price-list berulang-ulang.
  CREATE TABLE IF NOT EXISTS products (
    kode_produk    TEXT PRIMARY KEY,
    nama_produk    TEXT,
    brand          TEXT,
    harga_modal    INTEGER NOT NULL,
    tier           TEXT DEFAULT 'kompetitif_ketat',
    seller_status  TEXT DEFAULT 'unknown',
    updated_at     INTEGER NOT NULL
  );
`);

/**
 * Dipanggil endpoint pendaftaran order (server.js) — frontend WAJIB
 * memanggil ini sebelum/tepat setelah user submit transaksi on-chain,
 * supaya listener tahu nomor tujuan saat event OrderCreated terdeteksi.
 */
function registerOrder(orderId, customerNo, productCode) {
  const now = Date.now();
  const stmt = db.prepare(`
    INSERT INTO order_meta (order_id, customer_no, product_code, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(order_id) DO UPDATE SET customer_no = excluded.customer_no
  `);
  stmt.run(orderId, customerNo, productCode, now, now);
}

function getOrderMeta(orderId) {
  return db.prepare('SELECT * FROM order_meta WHERE order_id = ?').get(orderId);
}

function updateDigiflazzStatus(orderId, status, refId) {
  db.prepare(`
    UPDATE order_meta SET digiflazz_status = ?, ref_id = ?, updated_at = ?
    WHERE order_id = ?
  `).run(status, refId, Date.now(), orderId);
}

function updateOnchainStatus(orderId, status) {
  db.prepare(`
    UPDATE order_meta SET onchain_status = ?, updated_at = ?
    WHERE order_id = ?
  `).run(status, Date.now(), orderId);
}

function incrementRetry(orderId) {
  db.prepare(`
    UPDATE order_meta SET retry_count = retry_count + 1, updated_at = ?
    WHERE order_id = ?
  `).run(Date.now(), orderId);
}

/**
 * Cari order yang statusnya masih menggantung (belum dilaporkan ke
 * on-chain) — dipakai saat listener restart, supaya order yang
 * "terlewat" pas server down bisa diproses ulang.
 */
function getPendingOrders() {
  return db.prepare(`
    SELECT * FROM order_meta
    WHERE onchain_status = 'CREATED'
    ORDER BY created_at ASC
  `).all();
}

function getProduct(kodeProduk) {
  return db.prepare('SELECT * FROM products WHERE kode_produk = ?').get(kodeProduk);
}

function upsertProduct(kodeProduk, namaProduk, brand, hargaModal, tier, sellerStatus) {
  db.prepare(`
    INSERT INTO products (kode_produk, nama_produk, brand, harga_modal, tier, seller_status, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(kode_produk) DO UPDATE SET
      nama_produk = excluded.nama_produk,
      harga_modal = excluded.harga_modal,
      seller_status = excluded.seller_status,
      updated_at = excluded.updated_at
  `).run(kodeProduk, namaProduk, brand, hargaModal, tier, sellerStatus, Date.now());
}

module.exports = {
  registerOrder,
  getOrderMeta,
  updateDigiflazzStatus,
  updateOnchainStatus,
  incrementRetry,
  getPendingOrders,
  getProduct,
  upsertProduct,
};
