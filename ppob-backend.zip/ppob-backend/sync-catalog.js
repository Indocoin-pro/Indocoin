/**
 * sync-catalog.js
 * Tarik katalog produk dari Digiflazz (price-list API) dan simpan ke
 * database lokal (tabel `products`) — dipakai server.js untuk hitung
 * quote harga tanpa perlu panggil API Digiflazz tiap checkout.
 *
 * CARA PAKAI:
 *   node sync-catalog.js
 *
 * Jalankan berkala (misal via cron, 1-2x sehari) — BUKAN tiap menit,
 * sesuai anjuran resmi Digiflazz untuk tidak memanggil price-list
 * berulang-ulang.
 *
 * Catatan: tier markup di-assign otomatis dengan aturan sederhana
 * berdasarkan kategori — sesuaikan manual di database untuk produk
 * yang butuh tier khusus (misal paket Umroh → 'langka').
 */

require('dotenv').config();
const axios = require('axios');
const crypto = require('crypto');
const db = require('./db');

const USERNAME = process.env.DIGIFLAZZ_USERNAME;
const API_KEY = process.env.DIGIFLAZZ_APIKEY;

function sign() {
  return crypto.createHash('md5').update(USERNAME + API_KEY + 'pricelist').digest('hex');
}

/** Aturan sederhana penentuan tier — sesuaikan sesuai kebutuhan */
function tentukanTier(kategori, brand) {
  const kategoriLower = (kategori || '').toLowerCase();
  if (kategoriLower.includes('umroh') || kategoriLower.includes('enterprise')) {
    return 'langka';
  }
  if (kategoriLower.includes('bpjs') || kategoriLower.includes('pdam') || kategoriLower.includes('voucher')) {
    return 'kompetitif_sedang';
  }
  return 'kompetitif_ketat'; // default: pulsa, data, listrik
}

async function syncCatalog() {
  console.log('[sync-catalog] Mengambil daftar harga dari Digiflazz...');

  const res = await axios.post('https://api.digiflazz.com/v1/price-list', {
    cmd: 'prepaid',
    username: USERNAME,
    sign: sign(),
  });

  const produk = res.data.data;
  if (!produk || produk.length === 0) {
    console.log('[sync-catalog] Tidak ada produk ditemukan.');
    return;
  }

  let count = 0;
  for (const p of produk) {
    if (!p.buyer_product_status) continue; // skip yang belum di-ON-kan

    const tier = tentukanTier(p.category, p.brand);
    const sellerStatus = p.seller_product_status ? 'valid' : 'invalid';

    db.upsertProduct(p.buyer_sku_code, p.product_name, p.brand, p.price, tier, sellerStatus);
    count++;
  }

  console.log(`[sync-catalog] Selesai — ${count} produk aktif tersimpan ke database lokal.`);
}

syncCatalog().catch((err) => {
  console.error('[sync-catalog] Gagal sync:', err.message);
  process.exit(1);
});
